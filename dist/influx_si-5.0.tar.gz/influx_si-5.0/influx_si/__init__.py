import os, sys
dirmod=os.path.dirname(os.path.realpath(__file__))
sys.path.append(dirmod)
