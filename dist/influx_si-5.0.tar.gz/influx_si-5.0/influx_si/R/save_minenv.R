# save minimal environement for RPP simulation
save(param, labargs, file=sprintf("%s.RData", baseshort))
