# data for linear interpolation of 'A#1' isotopomer: 1-exp(-0.5*t)
df=read.table(file.path(dirw, "Akin.tsv"), header=TRUE)
